-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 04, 2018 at 03:54 AM
-- Server version: 5.6.34-log
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fusion-arte`
--

-- --------------------------------------------------------

--
-- Table structure for table `fa_commentmeta`
--

CREATE TABLE `fa_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fa_comments`
--

CREATE TABLE `fa_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `fa_comments`
--

INSERT INTO `fa_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Un Comentarista de WordPress', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-09-12 21:52:21', '2018-09-13 00:52:21', 'Hola, este es un comentario.\nPara empezar con la moderación, edición y eliminación de comentarios, por favor visita la pantalla de comentarios en el panel inicial.\nLos Avatares de los comentaristas provienen de <a href=\"https://gravatar.com\">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `fa_duplicator_packages`
--

CREATE TABLE `fa_duplicator_packages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(250) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner` varchar(60) NOT NULL,
  `package` mediumblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fa_il_local`
--

CREATE TABLE `fa_il_local` (
  `id` int(8) NOT NULL,
  `cep` varchar(8) NOT NULL,
  `logr_nr` varchar(30) DEFAULT NULL,
  `logr_end` varchar(30) DEFAULT NULL,
  `logr_bairro` varchar(30) DEFAULT NULL,
  `logr_cidade` varchar(30) DEFAULT NULL,
  `logr_estado` varchar(30) DEFAULT NULL,
  `lat` varchar(200) DEFAULT NULL,
  `lng` varchar(200) DEFAULT NULL,
  `show_order` int(4) DEFAULT NULL,
  `icon_id` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fa_links`
--

CREATE TABLE `fa_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fa_options`
--

CREATE TABLE `fa_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `fa_options`
--

INSERT INTO `fa_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8080', 'yes'),
(2, 'home', 'http://localhost:8080', 'yes'),
(3, 'blogname', 'Academia de Formación', 'yes'),
(4, 'blogdescription', 'Fusión Arte', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'mixsyandreapadilla@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:6:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:19:\"akismet/akismet.php\";i:2;s:36:\"contact-form-7/wp-contact-form-7.php\";i:3;s:25:\"duplicator/duplicator.php\";i:4;s:25:\"inlocation/inlocation.php\";i:5;s:24:\"wordpress-seo/wp-seo.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '-3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:71:\"C:\\Users\\Mixsy\\Desktop\\fusion-arte/wp-content/themes/proyecto/style.css\";i:1;s:0:\"\";}', 'no'),
(40, 'template', 'proyecto', 'yes'),
(41, 'stylesheet', 'proyecto', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '44', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '33', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '38590', 'yes'),
(94, 'fa_user_roles', 'a:7:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:37:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}}', 'yes'),
(95, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(96, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'fresh_site', '0', 'yes'),
(108, 'WPLANG', 'es_CL', 'yes'),
(109, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'sidebars_widgets', 'a:2:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(112, 'cron', 'a:6:{i:1538625143;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1538657543;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1538688812;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1538700760;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1538708534;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(113, 'theme_mods_twentyseventeen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1536800028;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(130, 'can_compress_scripts', '0', 'no'),
(143, 'current_theme', 'Proyecto', 'yes'),
(144, 'theme_mods_proyecto', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(145, 'theme_switched', '', 'yes'),
(216, 'new_admin_email', 'mixsyandreapadilla@gmail.com', 'yes'),
(228, 'recently_activated', 'a:1:{s:25:\"vanilla-forums/plugin.php\";i:1538433565;}', 'yes'),
(229, 'acf_version', '5.7.6', 'yes'),
(281, 'nav_menu_options', 'a:1:{s:8:\"auto_add\";a:0:{}}', 'yes'),
(317, 'category_children', 'a:0:{}', 'yes'),
(329, 'widget_akismet_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(337, 'wpseo', 'a:19:{s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:3:\"8.3\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";b:0;s:16:\"environment_type\";s:7:\"staging\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:0;s:18:\"first_activated_on\";i:1538362933;}', 'yes'),
(338, 'wpseo_titles', 'a:85:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:41:\"%%name%%, Author at %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:63:\"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:35:\"Page not found %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:53:\"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:1;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:25:\"Error 404: Page not found\";s:29:\"breadcrumbs-display-blog-page\";b:1;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:12:\"Archives for\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:4:\"Home\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:16:\"You searched for\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:12:\"website_name\";s:12:\"Fusión Arte\";s:11:\"person_name\";s:0:\"\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:58:\"http://localhost:8080/wp-content/uploads/2018/10/logo1.png\";s:12:\"company_name\";s:12:\"Fusión Arte\";s:17:\"company_or_person\";s:7:\"company\";s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:18:\"title-tax-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:1;s:23:\"noindex-tax-post_format\";b:1;s:23:\"post_types-post-maintax\";i:0;s:13:\"title-section\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:16:\"metadesc-section\";s:0:\"\";s:15:\"noindex-section\";b:0;s:16:\"showdate-section\";b:0;s:26:\"display-metabox-pt-section\";b:1;s:10:\"title-blog\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-blog\";s:0:\"\";s:12:\"noindex-blog\";b:0;s:13:\"showdate-blog\";b:0;s:23:\"display-metabox-pt-blog\";b:1;s:23:\"title-ptarchive-section\";s:51:\"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%\";s:26:\"metadesc-ptarchive-section\";s:0:\"\";s:25:\"bctitle-ptarchive-section\";s:0:\"\";s:25:\"noindex-ptarchive-section\";b:0;s:20:\"title-ptarchive-blog\";s:51:\"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%\";s:23:\"metadesc-ptarchive-blog\";s:0:\"\";s:22:\"bctitle-ptarchive-blog\";s:0:\"\";s:22:\"noindex-ptarchive-blog\";b:0;s:26:\"post_types-section-maintax\";i:0;s:23:\"post_types-blog-maintax\";i:0;}', 'yes'),
(339, 'wpseo_social', 'a:18:{s:13:\"facebook_site\";s:44:\"https://www.facebook.com/academia.fusionarte\";s:13:\"instagram_url\";s:44:\"https://www.instagram.com/fusionarte_oficial\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:14:\"plus-publisher\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:15:\"google_plus_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}', 'yes'),
(340, 'wpseo_flush_rewrite', '1', 'yes'),
(341, '_transient_timeout_wpseo_link_table_inaccessible', '1569898934', 'no'),
(342, '_transient_wpseo_link_table_inaccessible', '0', 'no'),
(343, '_transient_timeout_wpseo_meta_table_inaccessible', '1569898934', 'no'),
(344, '_transient_wpseo_meta_table_inaccessible', '0', 'no'),
(350, 'wpseo_sitemap_1_cache_validator', '6WN3w', 'no'),
(351, 'wpseo_sitemap_attachment_cache_validator', '6GFyW', 'no'),
(354, 'wpseo-gsc-refresh_token', '1/iwvxsXmaebSdIld-eXBhTG7hIzSeFFyz1XCXvyqGQwc', 'yes'),
(355, 'wpseo-gsc-access_token', 'a:5:{s:13:\"refresh_token\";s:45:\"1/iwvxsXmaebSdIld-eXBhTG7hIzSeFFyz1XCXvyqGQwc\";s:12:\"access_token\";s:176:\"ya29.GlwqBmjh202PzsCnZeaK17Qa16XeakIwD_mM7NfTxcHFAc74irw3zo248NsadCmam2VO2X7MaovjVfSfmB2lttHB5GD3NVyamJ0QEE0w-aatzjiOkMfCXf70kAPhFg.............................................\";s:7:\"expires\";i:1538510727;s:10:\"expires_in\";i:3600;s:7:\"created\";i:1538517927;}', 'yes'),
(357, 'wpseo-gsc', 'a:1:{s:7:\"profile\";s:0:\"\";}', 'yes'),
(359, 'wpseo_sitemap_cache_validator_global', 'PAs9', 'no'),
(364, 'rewrite_rules', 'a:140:{s:10:\"section/?$\";s:27:\"index.php?post_type=section\";s:40:\"section/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=section&feed=$matches[1]\";s:35:\"section/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=section&feed=$matches[1]\";s:27:\"section/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=section&paged=$matches[1]\";s:7:\"blog/?$\";s:24:\"index.php?post_type=blog\";s:37:\"blog/feed/(feed|rdf|rss|rss2|atom)/?$\";s:41:\"index.php?post_type=blog&feed=$matches[1]\";s:32:\"blog/(feed|rdf|rss|rss2|atom)/?$\";s:41:\"index.php?post_type=blog&feed=$matches[1]\";s:24:\"blog/page/([0-9]{1,})/?$\";s:42:\"index.php?post_type=blog&paged=$matches[1]\";s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:25:\"index.php?xsl=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:35:\"section/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"section/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"section/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"section/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"section/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"section/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"section/([^/]+)/embed/?$\";s:40:\"index.php?section=$matches[1]&embed=true\";s:28:\"section/([^/]+)/trackback/?$\";s:34:\"index.php?section=$matches[1]&tb=1\";s:48:\"section/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?section=$matches[1]&feed=$matches[2]\";s:43:\"section/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?section=$matches[1]&feed=$matches[2]\";s:36:\"section/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?section=$matches[1]&paged=$matches[2]\";s:43:\"section/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?section=$matches[1]&cpage=$matches[2]\";s:32:\"section/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?section=$matches[1]&page=$matches[2]\";s:24:\"section/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"section/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"section/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"section/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"section/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"section/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:32:\"blog/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"blog/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"blog/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"blog/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"blog/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"blog/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:21:\"blog/([^/]+)/embed/?$\";s:37:\"index.php?blog=$matches[1]&embed=true\";s:25:\"blog/([^/]+)/trackback/?$\";s:31:\"index.php?blog=$matches[1]&tb=1\";s:45:\"blog/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?blog=$matches[1]&feed=$matches[2]\";s:40:\"blog/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?blog=$matches[1]&feed=$matches[2]\";s:33:\"blog/([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?blog=$matches[1]&paged=$matches[2]\";s:40:\"blog/([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?blog=$matches[1]&cpage=$matches[2]\";s:29:\"blog/([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?blog=$matches[1]&page=$matches[2]\";s:21:\"blog/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:31:\"blog/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:51:\"blog/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"blog/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"blog/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:27:\"blog/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=44&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(365, 'wpseo_sitemap_page_cache_validator', '2dFo5', 'no'),
(395, 'wpseo_sitemap_acf-field-group_cache_validator', '6zkAE', 'no'),
(396, 'wpseo_sitemap_acf-field_cache_validator', '5CJzV', 'no'),
(403, 'wpseo_sitemap_about_cache_validator', '6VlgE', 'no'),
(410, 'wpseo_sitemap_nosotros_cache_validator', '6znlm', 'no'),
(445, 'wpcf7', 'a:2:{s:7:\"version\";s:5:\"5.0.4\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1538431310;s:7:\"version\";s:5:\"5.0.4\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(446, 'wpseo_sitemap_wpcf7_contact_form_cache_validator', '6E8C3', 'no'),
(450, 'wpseo_sitemap_home_cache_validator', '6JqhX', 'no'),
(486, '_transient_yoast_i18n_wordpress-seo_promo_hide', '1', 'yes'),
(493, 'duplicator_settings', 'a:10:{s:7:\"version\";s:6:\"1.2.48\";s:18:\"uninstall_settings\";b:1;s:15:\"uninstall_files\";b:1;s:16:\"uninstall_tables\";b:1;s:13:\"package_debug\";b:0;s:17:\"package_mysqldump\";b:1;s:22:\"package_mysqldump_path\";s:0:\"\";s:24:\"package_phpdump_qrylimit\";s:3:\"100\";s:17:\"package_zip_flush\";b:0;s:20:\"storage_htaccess_off\";b:0;}', 'yes'),
(494, 'duplicator_version_plugin', '1.2.48', 'yes'),
(499, 'wpseo_sitemap_author_cache_validator', '6WN8I', 'no'),
(524, '_site_transient_timeout_theme_roots', '1538626912', 'no'),
(525, '_site_transient_theme_roots', 'a:1:{s:8:\"proyecto\";s:7:\"/themes\";}', 'no'),
(527, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/es_CL/wordpress-4.9.8.zip\";s:6:\"locale\";s:5:\"es_CL\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/es_CL/wordpress-4.9.8.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.8\";s:7:\"version\";s:5:\"4.9.8\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1538625115;s:15:\"version_checked\";s:5:\"4.9.8\";s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:4:\"core\";s:4:\"slug\";s:7:\"default\";s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-28 18:50:14\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_CL.zip\";s:10:\"autoupdate\";b:1;}}}', 'no'),
(528, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1538625116;s:7:\"checked\";a:1:{s:8:\"proyecto\";s:5:\"1.1.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(529, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1538625117;s:7:\"checked\";a:6:{s:30:\"advanced-custom-fields/acf.php\";s:5:\"5.7.6\";s:19:\"akismet/akismet.php\";s:5:\"4.0.8\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.0.4\";s:25:\"duplicator/duplicator.php\";s:6:\"1.2.48\";s:25:\"inlocation/inlocation.php\";s:3:\"1.8\";s:24:\"wordpress-seo/wp-seo.php\";s:3:\"8.3\";}s:8:\"response\";a:1:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:5:\"5.7.7\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.5.7.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"4.9.9\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:2:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:14:\"contact-form-7\";s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.3.1\";s:7:\"updated\";s:19:\"2015-11-26 19:25:25\";s:7:\"package\";s:81:\"https://downloads.wordpress.org/translation/plugin/contact-form-7/4.3.1/es_CL.zip\";s:10:\"autoupdate\";b:1;}i:1;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:13:\"wordpress-seo\";s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:3:\"3.6\";s:7:\"updated\";s:19:\"2016-09-12 20:09:05\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/translation/plugin/wordpress-seo/3.6/es_CL.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:5:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.0.8\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.0.8.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.0.4\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.0.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:25:\"duplicator/duplicator.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:24:\"w.org/plugins/duplicator\";s:4:\"slug\";s:10:\"duplicator\";s:6:\"plugin\";s:25:\"duplicator/duplicator.php\";s:11:\"new_version\";s:6:\"1.2.48\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/duplicator/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/duplicator.1.2.48.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/duplicator/assets/icon-256x256.png?rev=1298463\";s:2:\"1x\";s:63:\"https://ps.w.org/duplicator/assets/icon-128x128.png?rev=1298463\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:65:\"https://ps.w.org/duplicator/assets/banner-772x250.png?rev=1645055\";}s:11:\"banners_rtl\";a:0:{}}s:25:\"inlocation/inlocation.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:24:\"w.org/plugins/inlocation\";s:4:\"slug\";s:10:\"inlocation\";s:6:\"plugin\";s:25:\"inlocation/inlocation.php\";s:11:\"new_version\";s:3:\"1.8\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/inlocation/\";s:7:\"package\";s:53:\"https://downloads.wordpress.org/plugin/inlocation.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:63:\"https://ps.w.org/inlocation/assets/icon-128x128.png?rev=1415968\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/inlocation/assets/banner-1544x500.png?rev=1415968\";s:2:\"1x\";s:65:\"https://ps.w.org/inlocation/assets/banner-772x250.png?rev=1415968\";}s:11:\"banners_rtl\";a:0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:3:\"8.3\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/wordpress-seo.8.3.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}}}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `fa_postmeta`
--

CREATE TABLE `fa_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `fa_postmeta`
--

INSERT INTO `fa_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(3, 5, '_edit_last', '1'),
(4, 5, '_edit_lock', '1538368964:1'),
(5, 7, '_edit_last', '1'),
(6, 7, '_edit_lock', '1537911152:1'),
(7, 9, '_edit_last', '1'),
(8, 9, '_edit_lock', '1537911180:1'),
(9, 11, '_edit_last', '1'),
(10, 11, '_edit_lock', '1538106876:1'),
(11, 15, '_edit_last', '1'),
(12, 15, '_edit_lock', '1538361756:1'),
(13, 18, '_edit_last', '1'),
(14, 18, '_edit_lock', '1538105887:1'),
(15, 22, '_edit_last', '1'),
(16, 22, '_edit_lock', '1538105958:1'),
(17, 18, '_wp_trash_meta_status', 'draft'),
(18, 18, '_wp_trash_meta_time', '1538106037'),
(19, 18, '_wp_desired_post_slug', ''),
(20, 22, '_wp_trash_meta_status', 'draft'),
(21, 22, '_wp_trash_meta_time', '1538106273'),
(22, 22, '_wp_desired_post_slug', ''),
(26, 1, '_wp_trash_meta_status', 'publish'),
(27, 1, '_wp_trash_meta_time', '1538106957'),
(28, 1, '_wp_desired_post_slug', 'hola-mundo'),
(29, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:\"1\";}'),
(30, 32, '_wp_attached_file', '2018/09/favicon.png'),
(31, 32, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:510;s:6:\"height\";i:511;s:4:\"file\";s:19:\"2018/09/favicon.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"favicon-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"favicon-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(32, 33, '_wp_attached_file', '2018/09/cropped-favicon.png'),
(33, 33, '_wp_attachment_context', 'site-icon'),
(34, 33, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:27:\"2018/09/cropped-favicon.png\";s:5:\"sizes\";a:6:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"cropped-favicon-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"cropped-favicon-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-270\";a:4:{s:4:\"file\";s:27:\"cropped-favicon-270x270.png\";s:5:\"width\";i:270;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-192\";a:4:{s:4:\"file\";s:27:\"cropped-favicon-192x192.png\";s:5:\"width\";i:192;s:6:\"height\";i:192;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-180\";a:4:{s:4:\"file\";s:27:\"cropped-favicon-180x180.png\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"site_icon-32\";a:4:{s:4:\"file\";s:25:\"cropped-favicon-32x32.png\";s:5:\"width\";i:32;s:6:\"height\";i:32;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(35, 34, '_wp_trash_meta_status', 'publish'),
(36, 34, '_wp_trash_meta_time', '1538250928'),
(37, 36, '_menu_item_type', 'post_type'),
(38, 36, '_menu_item_menu_item_parent', '0'),
(39, 36, '_menu_item_object_id', '11'),
(40, 36, '_menu_item_object', 'page'),
(41, 36, '_menu_item_target', ''),
(42, 36, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(43, 36, '_menu_item_xfn', ''),
(44, 36, '_menu_item_url', ''),
(45, 37, '_menu_item_type', 'post_type'),
(46, 37, '_menu_item_menu_item_parent', '0'),
(47, 37, '_menu_item_object_id', '9'),
(48, 37, '_menu_item_object', 'page'),
(49, 37, '_menu_item_target', ''),
(50, 37, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(51, 37, '_menu_item_xfn', ''),
(52, 37, '_menu_item_url', ''),
(53, 38, '_menu_item_type', 'post_type'),
(54, 38, '_menu_item_menu_item_parent', '0'),
(55, 38, '_menu_item_object_id', '7'),
(56, 38, '_menu_item_object', 'page'),
(57, 38, '_menu_item_target', ''),
(58, 38, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(59, 38, '_menu_item_xfn', ''),
(60, 38, '_menu_item_url', ''),
(61, 39, '_menu_item_type', 'post_type'),
(62, 39, '_menu_item_menu_item_parent', '0'),
(63, 39, '_menu_item_object_id', '5'),
(64, 39, '_menu_item_object', 'page'),
(65, 39, '_menu_item_target', ''),
(66, 39, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(67, 39, '_menu_item_xfn', ''),
(68, 39, '_menu_item_url', ''),
(69, 40, '_menu_item_type', 'custom'),
(70, 40, '_menu_item_menu_item_parent', '0'),
(71, 40, '_menu_item_object_id', '40'),
(72, 40, '_menu_item_object', 'custom'),
(73, 40, '_menu_item_target', ''),
(74, 40, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(75, 40, '_menu_item_xfn', ''),
(76, 40, '_menu_item_url', 'http://localhost:8080'),
(77, 35, '_wp_trash_meta_status', 'publish'),
(78, 35, '_wp_trash_meta_time', '1538250982'),
(79, 41, '_edit_lock', '1538266554:1'),
(80, 41, '_wp_trash_meta_status', 'publish'),
(81, 41, '_wp_trash_meta_time', '1538266558'),
(82, 42, '_edit_lock', '1538266854:1'),
(83, 42, '_wp_trash_meta_status', 'publish'),
(84, 42, '_wp_trash_meta_time', '1538266870'),
(86, 43, '_customize_changeset_uuid', 'b14c9bd9-ca27-4fdb-87b2-b0f7f18f5417'),
(88, 44, '_customize_changeset_uuid', 'b14c9bd9-ca27-4fdb-87b2-b0f7f18f5417'),
(90, 45, '_customize_changeset_uuid', 'b14c9bd9-ca27-4fdb-87b2-b0f7f18f5417'),
(91, 46, '_edit_lock', '1538266984:1'),
(92, 46, '_wp_trash_meta_status', 'publish'),
(93, 46, '_wp_trash_meta_time', '1538266994'),
(94, 50, '_wp_trash_meta_status', 'publish'),
(95, 50, '_wp_trash_meta_time', '1538346590'),
(96, 43, '_edit_lock', '1538351147:1'),
(97, 43, '_wp_trash_meta_status', 'publish'),
(98, 43, '_wp_trash_meta_time', '1538351290'),
(99, 43, '_wp_desired_post_slug', 'inicio'),
(100, 51, '_edit_lock', '1538353326:1'),
(101, 51, '_wp_trash_meta_status', 'publish'),
(102, 51, '_wp_trash_meta_time', '1538353330'),
(103, 52, '_wp_trash_meta_status', 'publish'),
(104, 52, '_wp_trash_meta_time', '1538353504'),
(105, 53, '_wp_trash_meta_status', 'publish'),
(106, 53, '_wp_trash_meta_time', '1538353527'),
(107, 55, '_edit_last', '1'),
(108, 55, '_edit_lock', '1538354197:1'),
(109, 55, '_wp_trash_meta_status', 'publish'),
(110, 55, '_wp_trash_meta_time', '1538354341'),
(111, 55, '_wp_desired_post_slug', 'group_5bb16a6104846'),
(112, 56, '_wp_trash_meta_status', 'publish'),
(113, 56, '_wp_trash_meta_time', '1538354341'),
(114, 56, '_wp_desired_post_slug', 'field_5bb16aa20051c'),
(115, 57, '_wp_trash_meta_status', 'publish'),
(116, 57, '_wp_trash_meta_time', '1538354341'),
(117, 57, '_wp_desired_post_slug', 'field_5bb16b870051e'),
(118, 59, '_edit_last', '1'),
(119, 59, '_edit_lock', '1538362491:1'),
(120, 15, '_wp_trash_meta_status', 'publish'),
(121, 15, '_wp_trash_meta_time', '1538361900'),
(122, 15, '_wp_desired_post_slug', 'nosotros'),
(129, 5, 'title', 'Quienes Somos'),
(130, 5, '_title', 'field_5bb16cda969da'),
(131, 5, 'image', '23'),
(132, 5, '_image', 'field_5bb16fbe969db'),
(133, 5, 'paragraph', 'Nuestro principal interés es poder introducir a niños, adolescentes y adultos en el estudio de las artes escénicas  a través de cada disciplina, la relación que estas  tienen con sus propias capacidades y entregar una instancia donde puedan, principalmente, descubrir sus habilidades, talentos  y desarrollarse de una manera sana con la disciplina que más les acomode.'),
(134, 5, '_paragraph', 'field_5bb17639969dc'),
(135, 66, 'title', 'Quienes Somos'),
(136, 66, '_title', 'field_5bb16cda969da'),
(137, 66, 'image', '23'),
(138, 66, '_image', 'field_5bb16fbe969db'),
(139, 66, 'paragraph', 'Nuestro principal interés es poder introducir a niños, adolescentes y adultos en el estudio de las artes escénicas  a través de cada disciplina, la relación que estas  tienen con sus propias capacidades y entregar una instancia donde puedan, principalmente, descubrir sus habilidades, talentos  y desarrollarse de una manera sana con la disciplina que más les acomode.'),
(140, 66, '_paragraph', 'field_5bb17639969dc'),
(147, 68, '_wp_attached_file', '2018/10/logo1.png'),
(148, 68, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:300;s:6:\"height\";i:137;s:4:\"file\";s:17:\"2018/10/logo1.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"logo1-150x137.png\";s:5:\"width\";i:150;s:6:\"height\";i:137;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"logo1-300x137.png\";s:5:\"width\";i:300;s:6:\"height\";i:137;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(149, 68, '_wp_attachment_image_alt', 'lofo fusión arte'),
(150, 5, '_yoast_wpseo_content_score', '60'),
(151, 70, 'title', 'Quienes Somos'),
(152, 70, '_title', 'field_5bb16cda969da'),
(153, 70, 'image', '23'),
(154, 70, '_image', 'field_5bb16fbe969db'),
(155, 70, 'paragraph', 'Nuestro principal interés es poder introducir a niños, adolescentes y adultos en el estudio de las artes escénicas  a través de cada disciplina, la relación que estas  tienen con sus propias capacidades y entregar una instancia donde puedan, principalmente, descubrir sus habilidades, talentos  y desarrollarse de una manera sana con la disciplina que más les acomode.'),
(156, 70, '_paragraph', 'field_5bb17639969dc'),
(157, 71, 'title', 'Quienes Somos'),
(158, 71, '_title', 'field_5bb16cda969da'),
(159, 71, 'image', '23'),
(160, 71, '_image', 'field_5bb16fbe969db'),
(161, 71, 'paragraph', 'Nuestro principal interés es poder introducir a niños, adolescentes y adultos en el estudio de las artes escénicas  a través de cada disciplina, la relación que estas  tienen con sus propias capacidades y entregar una instancia donde puedan, principalmente, descubrir sus habilidades, talentos  y desarrollarse de una manera sana con la disciplina que más les acomode.'),
(162, 71, '_paragraph', 'field_5bb17639969dc'),
(169, 59, '_wp_trash_meta_status', 'publish'),
(170, 59, '_wp_trash_meta_time', '1538415946'),
(171, 59, '_wp_desired_post_slug', 'group_5bb16cac71c48'),
(172, 60, '_wp_trash_meta_status', 'publish'),
(173, 60, '_wp_trash_meta_time', '1538415946'),
(174, 60, '_wp_desired_post_slug', 'field_5bb16cda969da'),
(175, 61, '_wp_trash_meta_status', 'publish'),
(176, 61, '_wp_trash_meta_time', '1538415947'),
(177, 61, '_wp_desired_post_slug', 'field_5bb16fbe969db'),
(178, 62, '_wp_trash_meta_status', 'publish'),
(179, 62, '_wp_trash_meta_time', '1538415947'),
(180, 62, '_wp_desired_post_slug', 'field_5bb17639969dc'),
(181, 74, '_edit_last', '1'),
(182, 74, '_edit_lock', '1538428879:1'),
(199, 88, '_wp_attached_file', '2018/10/ab1-e1538439616822.jpg'),
(200, 88, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:420;s:6:\"height\";i:568;s:4:\"file\";s:30:\"2018/10/ab1-e1538439616822.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"ab1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"ab1-222x300.jpg\";s:5:\"width\";i:222;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(201, 88, '_wp_attachment_backup_sizes', 'a:1:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:650;s:6:\"height\";i:879;s:4:\"file\";s:7:\"ab1.jpg\";}}'),
(202, 88, '_wp_attachment_image_alt', 'bailarina colores'),
(213, 90, '_wp_attached_file', '2018/10/ab2.jpg'),
(214, 90, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:650;s:6:\"height\";i:732;s:4:\"file\";s:15:\"2018/10/ab2.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"ab2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"ab2-266x300.jpg\";s:5:\"width\";i:266;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(215, 90, '_wp_attachment_image_alt', 'bailarin colores'),
(222, 92, '_edit_last', '1'),
(223, 92, '_edit_lock', '1538519748:1'),
(224, 93, '_wp_attached_file', '2018/10/ab3.jpg'),
(225, 93, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:600;s:6:\"height\";i:618;s:4:\"file\";s:15:\"2018/10/ab3.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"ab3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"ab3-291x300.jpg\";s:5:\"width\";i:291;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(226, 93, '_wp_attachment_image_alt', 'bailarina linea'),
(227, 92, '_thumbnail_id', '93'),
(228, 92, '_yoast_wpseo_primary_category', ''),
(229, 92, '_yoast_wpseo_content_score', '90'),
(233, 94, '_edit_last', '1'),
(234, 94, '_edit_lock', '1538520144:1'),
(235, 94, '_thumbnail_id', '90'),
(236, 94, '_yoast_wpseo_primary_category', ''),
(237, 94, '_yoast_wpseo_content_score', '90'),
(238, 95, '_edit_last', '1'),
(239, 95, '_edit_lock', '1538520301:1'),
(240, 95, '_thumbnail_id', '88'),
(241, 95, '_yoast_wpseo_primary_category', ''),
(242, 95, '_yoast_wpseo_content_score', '60'),
(243, 96, '_form', '<form>\n            <div class=\"row agile-contact-mid mb-lg-4 mb-3\">\n               <div class=\"col-lg-4 col-md-4 form-group contact-forms\">\n                  <input type=\"text\" class=\"form-control\" placeholder=\"Nombre\">\n               </div>\n               <div class=\"col-lg-4 col-md-4 form-group contact-forms\">\n                  <input type=\"email\" class=\"form-control\" placeholder=\"Email\">\n               </div>\n               <div class=\"col-lg-4 col-md-4 form-group contact-forms\">\n                  <input type=\"text\" class=\"form-control\" placeholder=\"Telefono\">\n               </div>\n            </div>\n            <div class=\"form-group contact-forms\">\n               <textarea class=\"form-control\" placeholder=\"Mensaje...\" ></textarea>\n            </div>\n            <button type=\"button\" class=\"btn sent-butnn btn-lg \">Enviar</button>\n         </form>'),
(244, 96, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:39:\"Academia de Formación \"[your-subject]\"\";s:6:\"sender\";s:42:\"[your-name] <mixsyandreapadilla@gmail.com>\";s:9:\"recipient\";s:28:\"mixsyandreapadilla@gmail.com\";s:4:\"body\";s:182:\"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Academia de Formación (http://localhost:8080)\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(245, 96, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:39:\"Academia de Formación \"[your-subject]\"\";s:6:\"sender\";s:53:\"Academia de Formación <mixsyandreapadilla@gmail.com>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:124:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Academia de Formación (http://localhost:8080)\";s:18:\"additional_headers\";s:38:\"Reply-To: mixsyandreapadilla@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(246, 96, '_messages', 'a:23:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}'),
(247, 96, '_additional_settings', ''),
(248, 96, '_locale', 'es_CL'),
(249, 97, '_edit_last', '1'),
(250, 97, '_edit_lock', '1538515898:1'),
(251, 98, '_wp_attached_file', '2018/10/ini3.png'),
(252, 98, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:470;s:6:\"height\";i:470;s:4:\"file\";s:16:\"2018/10/ini3.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"ini3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"ini3-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(253, 97, '_thumbnail_id', '98'),
(254, 97, '_yoast_wpseo_primary_category', ''),
(255, 97, '_yoast_wpseo_content_score', '90'),
(256, 99, '_edit_last', '1'),
(257, 99, '_edit_lock', '1538515802:1'),
(258, 100, '_wp_attached_file', '2018/10/ini2.png'),
(259, 100, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:470;s:6:\"height\";i:470;s:4:\"file\";s:16:\"2018/10/ini2.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"ini2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"ini2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(260, 100, '_wp_attachment_image_alt', 'pareja baile'),
(261, 99, '_thumbnail_id', '100'),
(262, 99, '_yoast_wpseo_primary_category', ''),
(263, 99, '_yoast_wpseo_content_score', '90'),
(264, 101, '_edit_last', '1'),
(265, 101, '_edit_lock', '1538520352:1'),
(266, 102, '_wp_attached_file', '2018/10/ini1.png'),
(267, 102, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:470;s:6:\"height\";i:470;s:4:\"file\";s:16:\"2018/10/ini1.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"ini1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"ini1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(268, 102, '_wp_attachment_image_alt', 'bailarina ballet'),
(269, 101, '_thumbnail_id', '102'),
(270, 101, '_yoast_wpseo_primary_category', ''),
(271, 101, '_yoast_wpseo_content_score', '60'),
(273, 96, '_config_errors', 'a:1:{s:23:\"mail.additional_headers\";a:1:{i:0;a:2:{s:4:\"code\";i:102;s:4:\"args\";a:3:{s:7:\"message\";s:51:\"Invalid mailbox syntax is used in the %name% field.\";s:6:\"params\";a:1:{s:4:\"name\";s:8:\"Reply-To\";}s:4:\"link\";s:68:\"https://contactform7.com/configuration-errors/invalid-mailbox-syntax\";}}}}'),
(276, 104, '_wp_attached_file', '2018/10/ser1-e1538517455902.jpg'),
(277, 104, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:400;s:6:\"height\";i:577;s:4:\"file\";s:31:\"2018/10/ser1-e1538517455902.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"ser1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"ser1-208x300.jpg\";s:5:\"width\";i:208;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:17:\"ser1-710x1024.jpg\";s:5:\"width\";i:710;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(281, 104, '_wp_attachment_backup_sizes', 'a:2:{s:9:\"full-orig\";a:3:{s:5:\"width\";i:718;s:6:\"height\";i:1036;s:4:\"file\";s:8:\"ser1.jpg\";}s:18:\"full-1538517455902\";a:3:{s:5:\"width\";i:500;s:6:\"height\";i:721;s:4:\"file\";s:23:\"ser1-e1538517429445.jpg\";}}');

-- --------------------------------------------------------

--
-- Table structure for table `fa_posts`
--

CREATE TABLE `fa_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `fa_posts`
--

INSERT INTO `fa_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-09-12 21:52:21', '2018-09-13 00:52:21', 'Bienvenido(a) a WordPress. Esta es tu primera entrada. Edítala o bórrala ¡y comienza a publicar!', '¡Hola mundo!', '', 'trash', 'open', 'open', '', 'hola-mundo__trashed', '', '', '2018-09-28 00:55:57', '2018-09-28 03:55:57', '', 0, 'http://localhost:8080/?p=1', 0, 'post', '', 1),
(5, 1, '2018-09-25 18:34:34', '2018-09-25 21:34:34', '<?php get_header() ?>\r\n\r\n<!-- banner -->\r\n<div class=\"inner_page-banner1\">\r\n</div>\r\n<!--//banner -->\r\n<!-- short -->\r\n<div class=\"using-border py-3\">\r\n   <div class=\"inner_breadcrumb  ml-4\">\r\n      <ul class=\"short_ls\">\r\n         <li>\r\n            <a href=\"index.html\">Inicio</a>\r\n            <span>/ /</span>\r\n        </li>\r\n        <li>Nosotros</li>\r\n    </ul>\r\n</div>\r\n</div>\r\n<!-- //short-->\r\n<!--about-->\r\n<div class=\"container\">\r\n  <section class=\"service py-lg-4 py-md-3 py-sm-3 py-3\">\r\n     <div class=\"container py-lg-5 py-md-4 py-sm-4 py-3\">\r\n        <h3 class=\"title text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3\"> Quienes Somos </h3> \r\n    </div>\r\n    <div class=\"row service-inner-agile mt-lg-4 mt-3\">\r\n     <div class=\"col-lg-4 col-md-4 service-img\">\r\n        <img class=img-fluid src=\"<?php echo get_theme_file_uri() ?>/assets/img/ab1.jpg\" alt=\"bailarina ballet multicolor\">\r\n        <div class=\"abt-sub-txt mt-lg-4 mt-3\">\r\n           <p>Nuestro principal interés es poder introducir a niños, adolescentes y adultos en el estudio de las artes escénicas  a través de cada disciplina, la relación que estas  tienen con sus propias capacidades y entregar una instancia donde puedan, principalmente, descubrir sus habilidades, talentos  y desarrollarse de una manera sana con la disciplina que más les acomode.</p>\r\n       </div>\r\n   </div>\r\n   <div class=\"col-lg-4 col-md-4 abut-inner-img\">\r\n      <img class=img-fluid src=\"<?php echo get_theme_file_uri() ?>/assets/img/ab2.jpg\" alt=\"bailarin  multicolor\">\r\n      <div class=\"abt-sub-txt mt-lg-4 mt-3\">\r\n         <p>Nuestra academia nace de la necesidad de  entregar  herramientas para  que cada alumno pueda desarrollarse de mejor manera desde lo artístico hacia el mundo cotidiano, ayudando transversalmente  a mejorar (en los niños principalmente) su vocabulario , expresión externa,  su  motricidad   , la disciplina y un mejor  desarrollo  socio cultural y comunicativo con su entorno y acercándolos a la cultura y las artes  desde sus propios intereses .</p>\r\n     </div>\r\n </div>\r\n <div class=\"col-lg-4 col-md-4 abut-inner-img\">\r\n   <img class=img-fluid src=\"<?php echo get_theme_file_uri() ?>/assets/img/ab3.jpg\" alt=\"bailarina multicolor\">\r\n   <div class=\"abt-sub-txt mt-lg-4 mt-3\">\r\n     <p>Nos interesa que, a través de la Danza y las Artes Escénicas, los alumnos puedan desarrollar una mejor conciencia corporal y lograr un desarrollo físico más allá de lo cotidiano, entregándoles, desde sus propias capacidades, una forma de expresar dancísticamente sus necesidades y anhelos.</p>\r\n </div>\r\n</div>\r\n</div>\r\n</div>\r\n</section>\r\n<!--//about-->\r\n<!--about-two-->\r\n<section>\r\n   <div class=\"container-fluid text-center\">\r\n      <div class=\"row abt-inner-agile\">\r\n         <div class=\"col-lg-6 col-md-6 two-abut-inner-right pr-0\">\r\n            <div class=\"sub-hedder-right text-left \">\r\n               <h4>Académia Fusión Arte</h4>\r\n               <p class=\"mt-3\">Visitanos academia de danza en Quilicura.</p>\r\n           </div>\r\n       </div>\r\n       <div class=\"col-lg-6 col-md-6 abut-inner-in p-0\">\r\n          <img class=\"img-fluid\" src=\"<?php echo get_theme_file_uri() ?>/assets/img/ab4.jpg\"alt=\"paqueñas bailando ballet\">\r\n      </div>\r\n  </div>\r\n</div>\r\n</div>\r\n</section>\r\n\r\n<!--//about-two-->\r\n<!--como contactarnos-->\r\n<section class=\"testimonial py-lg-4 py-md-3 py-sm-3 py-3\">\r\n   <div class=\"container py-lg-5 py-md-5 py-sm-4 py-3\">\r\n      <img id=\"title text-left mb-lg-5 mb-md-4 mb-sm-4 mb-3\" class=\"img-fluid\" src=\"<?php echo get_theme_file_uri() ?>/assets/img/Logo1.png\">\r\n\r\n      <div id=\"carouselExampleControls\" class=\"carousel slide\" data-ride=\"carousel\">\r\n         <div class=\"carousel-inner text-center\">\r\n            <div class=\"carousel-item active client-img\">\r\n               <img class=\"img-fluid\" src=\"<?php echo get_theme_file_uri() ?>/assets/img/f3.jpg\">\r\n               <div class=\"client-matter py-lg-4 py-md-3 py-3\">\r\n                  <p>ESTAMOS UBICADOS</p>\r\n                  <h6 class=\"pt-lg-3 pt-2\">Av. Bernardo O\'higgins 518, Quilicura</h6>\r\n              </div>\r\n          </div>\r\n          <div class=\"carousel-item client-img\">\r\n            <img class=\"img-fluid\" src=\"<?php echo get_theme_file_uri() ?>/assets/img/f1.jpg\">\r\n            \r\n            <div class=\"client-matter py-lg-4 py-md-3 py-3\">\r\n                <p>CONTÁCTANOS</p>\r\n                <h6 class=\"pt-lg-3 pt-2\">+56 9 7723 9967</h6>\r\n            </div>\r\n        </div>\r\n        <div class=\"carousel-item client-img\">\r\n          <img class=\"img-fluid\" src=\"<?php echo get_theme_file_uri() ?>/assets/img/f5.jpg\">\r\n          <div class=\"client-matter py-lg-4 py-md-3 py-3\">\r\n              <p>SÍGUENOS EN:</p>\r\n              <h6 class=\"pt-lg-3 pt-2\">FACEBOOK E INSTAGRAM</h6>\r\n          </div>\r\n      </div>\r\n  </div>\r\n  <a class=\"carousel-control-prev\" href=\"#carouselExampleControls\" role=\"button\" data-slide=\"prev\">\r\n   <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>\r\n   <span class=\"sr-only\">FISIÓN ARTE</span>\r\n</a>\r\n<a class=\"carousel-control-next\" href=\"#carouselExampleControls\" role=\"button\" data-slide=\"next\">\r\n   <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>\r\n   <span class=\"sr-only\">FISIÓN ARTE</span>\r\n</a>\r\n</div>\r\n</div>\r\n</section>\r\n<!--//como contactarnos -->\r\n\r\n<?php get_footer() ?>', 'Nosotros', '', 'publish', 'closed', 'closed', '', 'nosotros', '', '', '2018-10-01 01:38:32', '2018-10-01 04:38:32', '', 0, 'http://localhost:8080/?page_id=5', 1, 'page', '', 0),
(6, 1, '2018-09-25 18:34:34', '2018-09-25 21:34:34', '', 'Nosotros', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-09-25 18:34:34', '2018-09-25 21:34:34', '', 5, 'http://localhost:8080/2018/09/25/5-revision-v1/', 0, 'revision', '', 0),
(7, 1, '2018-09-25 18:34:51', '2018-09-25 21:34:51', '', 'Galería', '', 'publish', 'closed', 'closed', '', 'galeria', '', '', '2018-09-25 18:34:51', '2018-09-25 21:34:51', '', 0, 'http://localhost:8080/?page_id=7', 0, 'page', '', 0),
(8, 1, '2018-09-25 18:34:51', '2018-09-25 21:34:51', '', 'Galería', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2018-09-25 18:34:51', '2018-09-25 21:34:51', '', 7, 'http://localhost:8080/2018/09/25/7-revision-v1/', 0, 'revision', '', 0),
(9, 1, '2018-09-25 18:35:07', '2018-09-25 21:35:07', '', 'Compañía', '', 'publish', 'closed', 'closed', '', 'compania', '', '', '2018-09-25 18:35:18', '2018-09-25 21:35:18', '', 0, 'http://localhost:8080/?page_id=9', 0, 'page', '', 0),
(10, 1, '2018-09-25 18:35:07', '2018-09-25 21:35:07', '', 'Compañía', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2018-09-25 18:35:07', '2018-09-25 21:35:07', '', 9, 'http://localhost:8080/2018/09/25/9-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2018-09-25 18:35:29', '2018-09-25 21:35:29', '', 'Contacto', '', 'publish', 'closed', 'closed', '', 'contacto', '', '', '2018-09-25 18:35:29', '2018-09-25 21:35:29', '', 0, 'http://localhost:8080/?page_id=11', 0, 'page', '', 0),
(12, 1, '2018-09-25 18:35:29', '2018-09-25 21:35:29', '', 'Contacto', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2018-09-25 18:35:29', '2018-09-25 21:35:29', '', 11, 'http://localhost:8080/2018/09/25/11-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2018-09-27 20:56:38', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-09-27 20:56:38', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?p=13', 0, 'post', '', 0),
(14, 1, '2018-09-27 23:47:08', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-09-27 23:47:08', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=section&p=14', 0, 'section', '', 0),
(15, 1, '2018-09-28 00:55:30', '2018-09-28 03:55:30', '<img src=\"http://localhost:8080/wp-content/uploads/2018/09/ab1-222x300.jpg\" alt=\"bailarina ballet multicolor\" width=\"222\" height=\"300\" class=\"alignnone size-medium wp-image-23\" />Nuestro principal interés es poder introducir a niños, adolescentes y adultos en el estudio de las artes escénicas  a través de cada disciplina, la relación que estas  tienen con sus propias capacidades y entregar una instancia donde puedan, principalmente, descubrir sus habilidades, talentos  y desarrollarse de una manera sana con la disciplina que más les acomode.', 'Nosotros', '', 'trash', 'closed', 'closed', '', 'nosotros__trashed', '', '', '2018-09-30 23:45:00', '2018-10-01 02:45:00', '', 0, 'http://localhost:8080/?post_type=section&#038;p=15', 0, 'section', '', 0),
(16, 1, '2018-09-28 00:19:54', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-09-28 00:19:54', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=section&p=16', 0, 'section', '', 0),
(17, 1, '2018-09-28 00:19:56', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-09-28 00:19:56', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=section&p=17', 0, 'section', '', 0),
(18, 1, '2018-09-28 00:40:37', '2018-09-28 03:40:37', '', 'Nosotros', '', 'trash', 'closed', 'closed', '', '__trashed', '', '', '2018-09-28 00:40:37', '2018-09-28 03:40:37', '', 0, 'http://localhost:8080/?post_type=section&#038;p=18', 0, 'section', '', 0),
(19, 1, '2018-09-28 00:27:22', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-09-28 00:27:22', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=section&p=19', 0, 'section', '', 0),
(20, 1, '2018-09-28 00:31:09', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2018-09-28 00:31:09', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=section&p=20', 0, 'section', '', 0),
(21, 1, '2018-09-28 00:38:17', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-09-28 00:38:17', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=section&p=21', 0, 'section', '', 0),
(22, 1, '2018-09-28 00:44:33', '2018-09-28 03:44:33', '', '', '', 'trash', 'closed', 'closed', '', '__trashed-2', '', '', '2018-09-28 00:44:33', '2018-09-28 03:44:33', '', 0, 'http://localhost:8080/?post_type=section&#038;p=22', 0, 'section', '', 0),
(24, 1, '2018-09-28 00:55:57', '2018-09-28 03:55:57', 'Bienvenido(a) a WordPress. Esta es tu primera entrada. Edítala o bórrala ¡y comienza a publicar!', '¡Hola mundo!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2018-09-28 00:55:57', '2018-09-28 03:55:57', '', 1, 'http://localhost:8080/2018/09/28/1-revision-v1/', 0, 'revision', '', 0),
(27, 1, '2018-09-28 01:07:56', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-09-28 01:07:56', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?p=27', 0, 'post', '', 0),
(28, 1, '2018-09-28 01:08:31', '2018-09-28 04:08:31', '<img class=\"alignnone size-medium wp-image-23\" src=\"http://localhost:8080/wp-content/uploads/2018/09/ab1-222x300.jpg\" alt=\"bailarina ballet multicolor\" width=\"222\" height=\"300\" />', 'Nosotros', '', 'inherit', 'closed', 'closed', '', '15-autosave-v1', '', '', '2018-09-28 01:08:31', '2018-09-28 04:08:31', '', 15, 'http://localhost:8080/2018/09/28/15-autosave-v1/', 0, 'revision', '', 0),
(29, 1, '2018-09-28 02:18:33', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-09-28 02:18:33', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=acf-field-group&p=29', 0, 'acf-field-group', '', 0),
(30, 1, '2018-09-28 13:59:04', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-09-28 13:59:04', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=section&p=30', 0, 'section', '', 0),
(31, 1, '2018-09-28 21:18:25', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-09-28 21:18:25', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=acf-field-group&p=31', 0, 'acf-field-group', '', 0),
(32, 1, '2018-09-29 16:54:29', '2018-09-29 19:54:29', '', 'favicon', 'logo', 'inherit', 'open', 'closed', '', 'favicon', '', '', '2018-09-29 16:54:42', '2018-09-29 19:54:42', '', 0, 'http://localhost:8080/wp-content/uploads/2018/09/favicon.png', 0, 'attachment', 'image/png', 0),
(33, 1, '2018-09-29 16:54:44', '2018-09-29 19:54:44', 'http://localhost:8080/wp-content/uploads/2018/09/cropped-favicon.png', 'cropped-favicon.png', '', 'inherit', 'open', 'closed', '', 'cropped-favicon-png', '', '', '2018-09-29 16:54:44', '2018-09-29 19:54:44', '', 0, 'http://localhost:8080/wp-content/uploads/2018/09/cropped-favicon.png', 0, 'attachment', 'image/png', 0),
(34, 1, '2018-09-29 16:55:28', '2018-09-29 19:55:28', '{\n    \"blogdescription\": {\n        \"value\": \"Academia Fusi\\u00f3n Arte\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-29 19:55:28\"\n    },\n    \"site_icon\": {\n        \"value\": 33,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-29 19:55:28\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '95d3eb1c-6700-4c55-88a5-f00fd35039e0', '', '', '2018-09-29 16:55:28', '2018-09-29 19:55:28', '', 0, 'http://localhost:8080/2018/09/29/95d3eb1c-6700-4c55-88a5-f00fd35039e0/', 0, 'customize_changeset', '', 0),
(35, 1, '2018-09-29 16:56:19', '2018-09-29 19:56:19', '{\n    \"nav_menu[-1793135811]\": {\n        \"value\": {\n            \"name\": \"men\\u00fa\",\n            \"description\": \"\",\n            \"parent\": 0,\n            \"auto_add\": false\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-29 19:56:19\"\n    },\n    \"nav_menu_item[-869269157]\": {\n        \"value\": {\n            \"object_id\": 11,\n            \"object\": \"page\",\n            \"menu_item_parent\": 0,\n            \"position\": 1,\n            \"type\": \"post_type\",\n            \"title\": \"Contacto\",\n            \"url\": \"http://localhost:8080/contacto/\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Contacto\",\n            \"nav_menu_term_id\": -1793135811,\n            \"_invalid\": false,\n            \"type_label\": \"P\\u00e1gina\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-29 19:56:19\"\n    },\n    \"nav_menu_item[-1874433235]\": {\n        \"value\": {\n            \"object_id\": 9,\n            \"object\": \"page\",\n            \"menu_item_parent\": 0,\n            \"position\": 2,\n            \"type\": \"post_type\",\n            \"title\": \"Compa\\u00f1\\u00eda\",\n            \"url\": \"http://localhost:8080/compania/\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Compa\\u00f1\\u00eda\",\n            \"nav_menu_term_id\": -1793135811,\n            \"_invalid\": false,\n            \"type_label\": \"P\\u00e1gina\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-29 19:56:19\"\n    },\n    \"nav_menu_item[-1777321197]\": {\n        \"value\": {\n            \"object_id\": 7,\n            \"object\": \"page\",\n            \"menu_item_parent\": 0,\n            \"position\": 3,\n            \"type\": \"post_type\",\n            \"title\": \"Galer\\u00eda\",\n            \"url\": \"http://localhost:8080/galeria/\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Galer\\u00eda\",\n            \"nav_menu_term_id\": -1793135811,\n            \"_invalid\": false,\n            \"type_label\": \"P\\u00e1gina\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-29 19:56:19\"\n    },\n    \"nav_menu_item[-1442573769]\": {\n        \"value\": {\n            \"object_id\": 5,\n            \"object\": \"page\",\n            \"menu_item_parent\": 0,\n            \"position\": 4,\n            \"type\": \"post_type\",\n            \"title\": \"Nosotros\",\n            \"url\": \"http://localhost:8080/nosotros/\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Nosotros\",\n            \"nav_menu_term_id\": -1793135811,\n            \"_invalid\": false,\n            \"type_label\": \"P\\u00e1gina\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-29 19:56:19\"\n    },\n    \"nav_menu_item[-2081237917]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"\",\n            \"menu_item_parent\": 0,\n            \"position\": 5,\n            \"type\": \"custom\",\n            \"title\": \"Inicio\",\n            \"url\": \"http://localhost:8080\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Inicio\",\n            \"nav_menu_term_id\": -1793135811,\n            \"_invalid\": false,\n            \"type_label\": \"Enlace personalizado\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-29 19:56:19\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '97b15764-5037-414a-b7de-25046c4f69a6', '', '', '2018-09-29 16:56:19', '2018-09-29 19:56:19', '', 0, 'http://localhost:8080/2018/09/29/97b15764-5037-414a-b7de-25046c4f69a6/', 0, 'customize_changeset', '', 0),
(36, 1, '2018-09-29 16:56:20', '2018-09-29 19:56:20', ' ', '', '', 'publish', 'closed', 'closed', '', '36', '', '', '2018-09-30 21:22:09', '2018-10-01 00:22:09', '', 0, 'http://localhost:8080/2018/09/29/36/', 5, 'nav_menu_item', '', 0),
(37, 1, '2018-09-29 16:56:20', '2018-09-29 19:56:20', ' ', '', '', 'publish', 'closed', 'closed', '', '37', '', '', '2018-09-30 21:22:09', '2018-10-01 00:22:09', '', 0, 'http://localhost:8080/2018/09/29/37/', 4, 'nav_menu_item', '', 0),
(38, 1, '2018-09-29 16:56:20', '2018-09-29 19:56:20', ' ', '', '', 'publish', 'closed', 'closed', '', '38', '', '', '2018-09-30 21:22:09', '2018-10-01 00:22:09', '', 0, 'http://localhost:8080/2018/09/29/38/', 3, 'nav_menu_item', '', 0),
(39, 1, '2018-09-29 16:56:21', '2018-09-29 19:56:21', ' ', '', '', 'publish', 'closed', 'closed', '', '39', '', '', '2018-09-30 21:22:09', '2018-10-01 00:22:09', '', 0, 'http://localhost:8080/2018/09/29/39/', 2, 'nav_menu_item', '', 0),
(40, 1, '2018-09-29 16:56:21', '2018-09-29 19:56:21', '', 'Inicio', '', 'publish', 'closed', 'closed', '', 'inicio', '', '', '2018-09-30 21:22:10', '2018-10-01 00:22:10', '', 0, 'http://localhost:8080/2018/09/29/inicio/', 1, 'nav_menu_item', '', 0),
(41, 1, '2018-09-29 21:15:58', '2018-09-30 00:15:58', '{\n    \"blogname\": {\n        \"value\": \"Academia de Formaci\\u00f3n\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-30 00:15:41\"\n    },\n    \"blogdescription\": {\n        \"value\": \" Fusi\\u00f3n Arte\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-30 00:15:58\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '291d50b0-3309-4324-89a4-da6dfb65e416', '', '', '2018-09-29 21:15:58', '2018-09-30 00:15:58', '', 0, 'http://localhost:8080/?p=41', 0, 'customize_changeset', '', 0),
(42, 1, '2018-09-29 21:21:10', '2018-09-30 00:21:10', '{\n    \"blogname\": {\n        \"value\": \"Academia de Formaci\\u00f3n\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-30 00:20:44\"\n    },\n    \"blogdescription\": {\n        \"value\": \"Fusi\\u00f3n Arte\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-30 00:20:44\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'ce2154a6-803f-456b-a9c7-2ce29a75d1db', '', '', '2018-09-29 21:21:10', '2018-09-30 00:21:10', '', 0, 'http://localhost:8080/?p=42', 0, 'customize_changeset', '', 0),
(43, 1, '2018-09-29 21:23:13', '2018-09-30 00:23:13', '', 'inicio', '', 'trash', 'closed', 'closed', '', 'inicio__trashed', '', '', '2018-09-30 20:48:10', '2018-09-30 23:48:10', '', 0, 'http://localhost:8080/?page_id=43', 0, 'page', '', 0),
(44, 1, '2018-09-29 21:23:13', '2018-09-30 00:23:13', '', 'Inicio', '', 'publish', 'closed', 'closed', '', 'inicio-2', '', '', '2018-09-29 21:23:13', '2018-09-30 00:23:13', '', 0, 'http://localhost:8080/?page_id=44', 0, 'page', '', 0),
(45, 1, '2018-09-29 21:23:13', '2018-09-30 00:23:13', '', 'blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2018-09-29 21:23:13', '2018-09-30 00:23:13', '', 0, 'http://localhost:8080/?page_id=45', 0, 'page', '', 0),
(46, 1, '2018-09-29 21:23:13', '2018-09-30 00:23:13', '{\n    \"show_on_front\": {\n        \"value\": \"page\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-30 00:23:04\"\n    },\n    \"page_on_front\": {\n        \"value\": \"44\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-30 00:23:04\"\n    },\n    \"page_for_posts\": {\n        \"value\": \"0\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-30 00:23:13\"\n    },\n    \"nav_menus_created_posts\": {\n        \"value\": [\n            43,\n            44,\n            45\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-30 00:23:04\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'b14c9bd9-ca27-4fdb-87b2-b0f7f18f5417', '', '', '2018-09-29 21:23:13', '2018-09-30 00:23:13', '', 0, 'http://localhost:8080/?p=46', 0, 'customize_changeset', '', 0),
(47, 1, '2018-09-29 21:23:13', '2018-09-30 00:23:13', '', 'inicio', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2018-09-29 21:23:13', '2018-09-30 00:23:13', '', 43, 'http://localhost:8080/2018/09/29/43-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2018-09-29 21:23:13', '2018-09-30 00:23:13', '', 'Inicio', '', 'inherit', 'closed', 'closed', '', '44-revision-v1', '', '', '2018-09-29 21:23:13', '2018-09-30 00:23:13', '', 44, 'http://localhost:8080/2018/09/29/44-revision-v1/', 0, 'revision', '', 0),
(49, 1, '2018-09-29 21:23:13', '2018-09-30 00:23:13', '', 'blog', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2018-09-29 21:23:13', '2018-09-30 00:23:13', '', 45, 'http://localhost:8080/2018/09/29/45-revision-v1/', 0, 'revision', '', 0),
(50, 1, '2018-09-30 19:29:50', '2018-09-30 22:29:50', '{\n    \"blogname\": {\n        \"value\": \"Academia de Formaci\\u00f3n\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-30 22:29:50\"\n    },\n    \"blogdescription\": {\n        \"value\": \"Fusi\\u00f3n Arte\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-09-30 22:29:50\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '438ea18b-ec33-4f67-9133-4e42cf3f717e', '', '', '2018-09-30 19:29:50', '2018-09-30 22:29:50', '', 0, 'http://localhost:8080/2018/09/30/438ea18b-ec33-4f67-9133-4e42cf3f717e/', 0, 'customize_changeset', '', 0),
(51, 1, '2018-09-30 21:22:09', '2018-10-01 00:22:09', '{\n    \"nav_menu_item[36]\": {\n        \"value\": {\n            \"menu_item_parent\": 0,\n            \"object_id\": 11,\n            \"object\": \"page\",\n            \"type\": \"post_type\",\n            \"type_label\": \"P\\u00e1gina\",\n            \"url\": \"http://localhost:8080/contacto/\",\n            \"title\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 3,\n            \"position\": 5,\n            \"status\": \"publish\",\n            \"original_title\": \"Contacto\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-10-01 00:22:06\"\n    },\n    \"nav_menu_item[37]\": {\n        \"value\": {\n            \"menu_item_parent\": 0,\n            \"object_id\": 9,\n            \"object\": \"page\",\n            \"type\": \"post_type\",\n            \"type_label\": \"P\\u00e1gina\",\n            \"url\": \"http://localhost:8080/compania/\",\n            \"title\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 3,\n            \"position\": 4,\n            \"status\": \"publish\",\n            \"original_title\": \"Compa\\u00f1\\u00eda\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-10-01 00:22:06\"\n    },\n    \"nav_menu_item[38]\": {\n        \"value\": {\n            \"menu_item_parent\": 0,\n            \"object_id\": 7,\n            \"object\": \"page\",\n            \"type\": \"post_type\",\n            \"type_label\": \"P\\u00e1gina\",\n            \"url\": \"http://localhost:8080/galeria/\",\n            \"title\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 3,\n            \"position\": 3,\n            \"status\": \"publish\",\n            \"original_title\": \"Galer\\u00eda\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-10-01 00:22:06\"\n    },\n    \"nav_menu_item[39]\": {\n        \"value\": {\n            \"menu_item_parent\": 0,\n            \"object_id\": 5,\n            \"object\": \"page\",\n            \"type\": \"post_type\",\n            \"type_label\": \"P\\u00e1gina\",\n            \"url\": \"http://localhost:8080/nosotros/\",\n            \"title\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 3,\n            \"position\": 2,\n            \"status\": \"publish\",\n            \"original_title\": \"Nosotros\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-10-01 00:22:06\"\n    },\n    \"nav_menu_item[40]\": {\n        \"value\": {\n            \"menu_item_parent\": 0,\n            \"object_id\": 40,\n            \"object\": \"custom\",\n            \"type\": \"custom\",\n            \"type_label\": \"Enlace personalizado\",\n            \"title\": \"Inicio\",\n            \"url\": \"http://localhost:8080\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 3,\n            \"position\": 1,\n            \"status\": \"publish\",\n            \"original_title\": \"\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-10-01 00:22:06\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '69295f1e-f055-4e38-96b4-694cf0faa681', '', '', '2018-09-30 21:22:09', '2018-10-01 00:22:09', '', 0, 'http://localhost:8080/?p=51', 0, 'customize_changeset', '', 0),
(52, 1, '2018-09-30 21:25:04', '2018-10-01 00:25:04', '{\n    \"nav_menu[3]\": {\n        \"value\": {\n            \"name\": \"men\\u00fa\",\n            \"description\": \"\",\n            \"parent\": 0,\n            \"auto_add\": true\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-10-01 00:25:04\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'b667b277-98c6-439b-b583-73593c8f559b', '', '', '2018-09-30 21:25:04', '2018-10-01 00:25:04', '', 0, 'http://localhost:8080/2018/09/30/b667b277-98c6-439b-b583-73593c8f559b/', 0, 'customize_changeset', '', 0),
(53, 1, '2018-09-30 21:25:27', '2018-10-01 00:25:27', '{\n    \"nav_menu[3]\": {\n        \"value\": {\n            \"name\": \"men\\u00fa\",\n            \"description\": \"\",\n            \"parent\": 0,\n            \"auto_add\": false\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-10-01 00:25:27\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '6bd963ed-3abd-4748-be68-c44a9e954d31', '', '', '2018-09-30 21:25:27', '2018-10-01 00:25:27', '', 0, 'http://localhost:8080/2018/09/30/6bd963ed-3abd-4748-be68-c44a9e954d31/', 0, 'customize_changeset', '', 0),
(54, 1, '2018-09-30 21:28:51', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-09-30 21:28:51', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=acf-field-group&p=54', 0, 'acf-field-group', '', 0),
(55, 1, '2018-09-30 21:34:58', '2018-10-01 00:34:58', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"5\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Nosotros', 'nosotros', 'trash', 'closed', 'closed', '', 'group_5bb16a6104846__trashed', '', '', '2018-09-30 21:39:01', '2018-10-01 00:39:01', '', 0, 'http://localhost:8080/?post_type=acf-field-group&#038;p=55', 0, 'acf-field-group', '', 0),
(56, 1, '2018-09-30 21:34:58', '2018-10-01 00:34:58', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:36:\"Siempre debe ir texto en este campo.\";s:8:\"required\";i:1;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:12:\"Fusión Arte\";s:11:\"placeholder\";s:8:\"Nosotros\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:17:\"conditional_logic\";a:2:{i:0;a:1:{i:0;a:2:{s:8:\"operator\";s:0:\"\";s:5:\"value\";s:0:\"\";}}i:1;a:1:{i:0;a:2:{s:8:\"operator\";s:0:\"\";s:5:\"value\";s:0:\"\";}}}}', 'Nosotros', 'nosotros', 'trash', 'closed', 'closed', '', 'field_5bb16aa20051c__trashed', '', '', '2018-09-30 21:39:01', '2018-10-01 00:39:01', '', 55, 'http://localhost:8080/?post_type=acf-field&#038;p=56', 0, 'acf-field', '', 0),
(57, 1, '2018-09-30 21:34:58', '2018-10-01 00:34:58', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', '', '', 'trash', 'closed', 'closed', '', 'field_5bb16b870051e__trashed', '', '', '2018-09-30 21:39:01', '2018-10-01 00:39:01', '', 55, 'http://localhost:8080/?post_type=acf-field&#038;p=57', 1, 'acf-field', '', 0),
(58, 1, '2018-09-30 21:37:37', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-09-30 21:37:37', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=acf-field-group&p=58', 0, 'acf-field-group', '', 0),
(59, 1, '2018-09-30 22:44:36', '2018-10-01 01:44:36', 'a:7:{s:8:\"location\";a:1:{i:0;a:2:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"5\";}i:1;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"5\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'NOSOTROS', 'nosotros', 'trash', 'closed', 'closed', '', 'group_5bb16cac71c48__trashed', '', '', '2018-10-01 14:45:46', '2018-10-01 17:45:46', '', 0, 'http://localhost:8080/?post_type=acf-field-group&#038;p=59', 0, 'acf-field-group', '', 0),
(60, 1, '2018-09-30 22:44:37', '2018-10-01 01:44:37', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:41:\"Agrega aquí el título de Quienes Somos.\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:13:\"Quienes Somos\";s:11:\"placeholder\";s:42:\"Escribe aquí el título de quienes somos.\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'titulo', 'title', 'trash', 'closed', 'closed', '', 'field_5bb16cda969da__trashed', '', '', '2018-10-01 14:45:46', '2018-10-01 17:45:46', '', 59, 'http://localhost:8080/?post_type=acf-field&#038;p=60', 0, 'acf-field', '', 0),
(61, 1, '2018-09-30 22:44:37', '2018-10-01 01:44:37', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:25:\"Agregue la primera imagen\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Imagenes', 'image', 'trash', 'closed', 'closed', '', 'field_5bb16fbe969db__trashed', '', '', '2018-10-01 14:45:47', '2018-10-01 17:45:47', '', 59, 'http://localhost:8080/?post_type=acf-field&#038;p=61', 1, 'acf-field', '', 0),
(62, 1, '2018-09-30 22:44:37', '2018-10-01 01:44:37', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:46:\"agrega parrafo de imagen uno de quienes somos.\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:26:\"Escribe aquí párrafo uno\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'parrafo', 'paragraph', 'trash', 'closed', 'closed', '', 'field_5bb17639969dc__trashed', '', '', '2018-10-01 14:45:47', '2018-10-01 17:45:47', '', 59, 'http://localhost:8080/?post_type=acf-field&#038;p=62', 2, 'acf-field', '', 0),
(64, 1, '2018-09-30 23:46:10', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-09-30 23:46:10', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=section&p=64', 0, 'section', '', 0),
(66, 1, '2018-09-30 23:55:26', '2018-10-01 02:55:26', '', 'Nosotros', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-09-30 23:55:26', '2018-10-01 02:55:26', '', 5, 'http://localhost:8080/2018/09/30/5-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2018-10-01 00:06:01', '2018-10-01 03:06:01', '', 'logo1', '', 'inherit', 'open', 'closed', '', 'logo1', '', '', '2018-10-01 00:06:16', '2018-10-01 03:06:16', '', 0, 'http://localhost:8080/wp-content/uploads/2018/10/logo1.png', 0, 'attachment', 'image/png', 0),
(70, 1, '2018-10-01 00:36:19', '2018-10-01 03:36:19', 'Nuestro principal interés es poder introducir a niños, adolescentes y adultos en el estudio de las artes escénicas a través de cada disciplina, la relación que estas tienen con sus propias capacidades y entregar una instancia donde puedan, principalmente, descubrir sus habilidades, talentos y desarrollarse de una manera sana con la disciplina que más les acomode.', 'Nosotros', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-10-01 00:36:19', '2018-10-01 03:36:19', '', 5, 'http://localhost:8080/2018/10/01/5-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2018-10-01 01:38:32', '2018-10-01 04:38:32', '<?php get_header() ?>\r\n\r\n<!-- banner -->\r\n<div class=\"inner_page-banner1\">\r\n</div>\r\n<!--//banner -->\r\n<!-- short -->\r\n<div class=\"using-border py-3\">\r\n   <div class=\"inner_breadcrumb  ml-4\">\r\n      <ul class=\"short_ls\">\r\n         <li>\r\n            <a href=\"index.html\">Inicio</a>\r\n            <span>/ /</span>\r\n        </li>\r\n        <li>Nosotros</li>\r\n    </ul>\r\n</div>\r\n</div>\r\n<!-- //short-->\r\n<!--about-->\r\n<div class=\"container\">\r\n  <section class=\"service py-lg-4 py-md-3 py-sm-3 py-3\">\r\n     <div class=\"container py-lg-5 py-md-4 py-sm-4 py-3\">\r\n        <h3 class=\"title text-center mb-lg-5 mb-md-4 mb-sm-4 mb-3\"> Quienes Somos </h3> \r\n    </div>\r\n    <div class=\"row service-inner-agile mt-lg-4 mt-3\">\r\n     <div class=\"col-lg-4 col-md-4 service-img\">\r\n        <img class=img-fluid src=\"<?php echo get_theme_file_uri() ?>/assets/img/ab1.jpg\" alt=\"bailarina ballet multicolor\">\r\n        <div class=\"abt-sub-txt mt-lg-4 mt-3\">\r\n           <p>Nuestro principal interés es poder introducir a niños, adolescentes y adultos en el estudio de las artes escénicas  a través de cada disciplina, la relación que estas  tienen con sus propias capacidades y entregar una instancia donde puedan, principalmente, descubrir sus habilidades, talentos  y desarrollarse de una manera sana con la disciplina que más les acomode.</p>\r\n       </div>\r\n   </div>\r\n   <div class=\"col-lg-4 col-md-4 abut-inner-img\">\r\n      <img class=img-fluid src=\"<?php echo get_theme_file_uri() ?>/assets/img/ab2.jpg\" alt=\"bailarin  multicolor\">\r\n      <div class=\"abt-sub-txt mt-lg-4 mt-3\">\r\n         <p>Nuestra academia nace de la necesidad de  entregar  herramientas para  que cada alumno pueda desarrollarse de mejor manera desde lo artístico hacia el mundo cotidiano, ayudando transversalmente  a mejorar (en los niños principalmente) su vocabulario , expresión externa,  su  motricidad   , la disciplina y un mejor  desarrollo  socio cultural y comunicativo con su entorno y acercándolos a la cultura y las artes  desde sus propios intereses .</p>\r\n     </div>\r\n </div>\r\n <div class=\"col-lg-4 col-md-4 abut-inner-img\">\r\n   <img class=img-fluid src=\"<?php echo get_theme_file_uri() ?>/assets/img/ab3.jpg\" alt=\"bailarina multicolor\">\r\n   <div class=\"abt-sub-txt mt-lg-4 mt-3\">\r\n     <p>Nos interesa que, a través de la Danza y las Artes Escénicas, los alumnos puedan desarrollar una mejor conciencia corporal y lograr un desarrollo físico más allá de lo cotidiano, entregándoles, desde sus propias capacidades, una forma de expresar dancísticamente sus necesidades y anhelos.</p>\r\n </div>\r\n</div>\r\n</div>\r\n</div>\r\n</section>\r\n<!--//about-->\r\n<!--about-two-->\r\n<section>\r\n   <div class=\"container-fluid text-center\">\r\n      <div class=\"row abt-inner-agile\">\r\n         <div class=\"col-lg-6 col-md-6 two-abut-inner-right pr-0\">\r\n            <div class=\"sub-hedder-right text-left \">\r\n               <h4>Académia Fusión Arte</h4>\r\n               <p class=\"mt-3\">Visitanos academia de danza en Quilicura.</p>\r\n           </div>\r\n       </div>\r\n       <div class=\"col-lg-6 col-md-6 abut-inner-in p-0\">\r\n          <img class=\"img-fluid\" src=\"<?php echo get_theme_file_uri() ?>/assets/img/ab4.jpg\"alt=\"paqueñas bailando ballet\">\r\n      </div>\r\n  </div>\r\n</div>\r\n</div>\r\n</section>\r\n\r\n<!--//about-two-->\r\n<!--como contactarnos-->\r\n<section class=\"testimonial py-lg-4 py-md-3 py-sm-3 py-3\">\r\n   <div class=\"container py-lg-5 py-md-5 py-sm-4 py-3\">\r\n      <img id=\"title text-left mb-lg-5 mb-md-4 mb-sm-4 mb-3\" class=\"img-fluid\" src=\"<?php echo get_theme_file_uri() ?>/assets/img/Logo1.png\">\r\n\r\n      <div id=\"carouselExampleControls\" class=\"carousel slide\" data-ride=\"carousel\">\r\n         <div class=\"carousel-inner text-center\">\r\n            <div class=\"carousel-item active client-img\">\r\n               <img class=\"img-fluid\" src=\"<?php echo get_theme_file_uri() ?>/assets/img/f3.jpg\">\r\n               <div class=\"client-matter py-lg-4 py-md-3 py-3\">\r\n                  <p>ESTAMOS UBICADOS</p>\r\n                  <h6 class=\"pt-lg-3 pt-2\">Av. Bernardo O\'higgins 518, Quilicura</h6>\r\n              </div>\r\n          </div>\r\n          <div class=\"carousel-item client-img\">\r\n            <img class=\"img-fluid\" src=\"<?php echo get_theme_file_uri() ?>/assets/img/f1.jpg\">\r\n            \r\n            <div class=\"client-matter py-lg-4 py-md-3 py-3\">\r\n                <p>CONTÁCTANOS</p>\r\n                <h6 class=\"pt-lg-3 pt-2\">+56 9 7723 9967</h6>\r\n            </div>\r\n        </div>\r\n        <div class=\"carousel-item client-img\">\r\n          <img class=\"img-fluid\" src=\"<?php echo get_theme_file_uri() ?>/assets/img/f5.jpg\">\r\n          <div class=\"client-matter py-lg-4 py-md-3 py-3\">\r\n              <p>SÍGUENOS EN:</p>\r\n              <h6 class=\"pt-lg-3 pt-2\">FACEBOOK E INSTAGRAM</h6>\r\n          </div>\r\n      </div>\r\n  </div>\r\n  <a class=\"carousel-control-prev\" href=\"#carouselExampleControls\" role=\"button\" data-slide=\"prev\">\r\n   <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>\r\n   <span class=\"sr-only\">FISIÓN ARTE</span>\r\n</a>\r\n<a class=\"carousel-control-next\" href=\"#carouselExampleControls\" role=\"button\" data-slide=\"next\">\r\n   <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>\r\n   <span class=\"sr-only\">FISIÓN ARTE</span>\r\n</a>\r\n</div>\r\n</div>\r\n</section>\r\n<!--//como contactarnos -->\r\n\r\n<?php get_footer() ?>', 'Nosotros', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-10-01 01:38:32', '2018-10-01 04:38:32', '', 5, 'http://localhost:8080/2018/10/01/5-revision-v1/', 0, 'revision', '', 0),
(72, 1, '2018-10-01 01:42:30', '2018-10-01 04:42:30', '', 'Nosotros', '', 'inherit', 'closed', 'closed', '', '5-autosave-v1', '', '', '2018-10-01 01:42:30', '2018-10-01 04:42:30', '', 5, 'http://localhost:8080/2018/10/01/5-autosave-v1/', 0, 'revision', '', 0),
(73, 1, '2018-10-01 15:57:20', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-10-01 15:57:20', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=about&p=73', 0, 'about', '', 0),
(74, 1, '2018-10-01 18:14:56', '2018-10-01 21:14:56', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:8:\"nosotros\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Nosotros', 'nosotros', 'publish', 'closed', 'closed', '', 'group_5bb28e16a6254', '', '', '2018-10-01 18:23:39', '2018-10-01 21:23:39', '', 0, 'http://localhost:8080/?post_type=acf-field-group&#038;p=74', 0, 'acf-field-group', '', 0),
(75, 1, '2018-10-01 18:15:14', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-10-01 18:15:14', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=about&p=75', 0, 'about', '', 0),
(76, 1, '2018-10-01 18:15:16', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-10-01 18:15:16', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=about&p=76', 0, 'about', '', 0),
(77, 1, '2018-10-01 18:17:00', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-10-01 18:17:00', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=about&p=77', 0, 'about', '', 0),
(78, 1, '2018-10-01 18:21:53', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-10-01 18:21:53', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=nosotros&p=78', 0, 'nosotros', '', 0),
(79, 1, '2018-10-01 18:23:10', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-10-01 18:23:10', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=nosotros&p=79', 0, 'nosotros', '', 0),
(80, 1, '2018-10-01 18:23:47', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-10-01 18:23:47', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=nosotros&p=80', 0, 'nosotros', '', 0),
(82, 1, '2018-10-01 20:21:52', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-10-01 20:21:52', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=about&p=82', 0, 'about', '', 0),
(83, 1, '2018-10-01 20:23:36', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-10-01 20:23:36', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=about&p=83', 0, 'about', '', 0),
(84, 1, '2018-10-01 20:24:13', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2018-10-01 20:24:13', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/?post_type=about&p=84', 0, 'about', '', 0),
(88, 1, '2018-10-01 21:20:07', '2018-10-02 00:20:07', '', 'ab1', '', 'inherit', 'open', 'closed', '', 'ab1', '', '', '2018-10-01 21:20:36', '2018-10-02 00:20:36', '', 0, 'http://localhost:8080/wp-content/uploads/2018/10/ab1.jpg', 0, 'attachment', 'image/jpeg', 0),
(90, 1, '2018-10-01 21:47:47', '2018-10-02 00:47:47', '', 'ab2', '', 'inherit', 'open', 'closed', '', 'ab2', '', '', '2018-10-01 21:47:56', '2018-10-02 00:47:56', '', 0, 'http://localhost:8080/wp-content/uploads/2018/10/ab2.jpg', 0, 'attachment', 'image/jpeg', 0),
(92, 1, '2018-10-01 21:51:02', '2018-10-02 00:51:02', ' <p>Nos interesa que a través de la Danza y las Artes Escénicas, los alumnos puedan desarrollar una mejor conciencia corporal. Lograr así un desarrollo físico más allá de lo cotidiano. Entregándoles desde sus propias capacidades, una forma de expresar dancísticamente sus necesidades y anhelos.</p>', 'bailarina-3', '', 'publish', 'closed', 'closed', '', 'bailarina-3', '', '', '2018-10-02 19:37:59', '2018-10-02 22:37:59', '', 0, 'http://localhost:8080/?post_type=about&#038;p=92', 0, 'about', '', 0),
(93, 1, '2018-10-01 21:50:44', '2018-10-02 00:50:44', '', 'ab3', '', 'inherit', 'open', 'closed', '', 'ab3', '', '', '2018-10-01 21:51:00', '2018-10-02 00:51:00', '', 92, 'http://localhost:8080/wp-content/uploads/2018/10/ab3.jpg', 0, 'attachment', 'image/jpeg', 0),
(94, 1, '2018-10-01 21:52:47', '2018-10-02 00:52:47', ' <p>Nuestra academia nace de la necesidad de  entregar  herramientas. Cada alumno podrá desarrollarse de mejor manera desde lo artístico hacia el mundo cotidiano. Ayudando transversalmente  a mejorar. (En los niños principalmente) su vocabulario , expresión externa,  su  motricidad   , la disciplina y un mejor  desarrollo  socio cultural y comunicativo. En su entorno los acercámos a la cultura y las artes  desde sus propios intereses.</p>', 'bailarin-2', '', 'publish', 'closed', 'closed', '', 'bailarin-2', '', '', '2018-10-02 19:44:40', '2018-10-02 22:44:40', '', 0, 'http://localhost:8080/?post_type=about&#038;p=94', 0, 'about', '', 0),
(95, 1, '2018-10-01 21:53:18', '2018-10-02 00:53:18', ' <p>Nuestro principal interés es poder introducir a niños, adolescentes y adultos en el estudio de las artes escénicas.  A través de cada disciplina, la relación que estas tienen con sus propias capacidades para entregar una instancia donde puedan principalmente descubrir sus habilidades y talentos. Se podrán esarrollar de una manera sana con la disciplina que más les acomode.</p>\r\n', 'bailarina-1', '', 'publish', 'closed', 'closed', '', 'bailarina-1', '', '', '2018-10-02 19:46:55', '2018-10-02 22:46:55', '', 0, 'http://localhost:8080/?post_type=about&#038;p=95', 0, 'about', '', 0);
INSERT INTO `fa_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(96, 1, '2018-10-01 22:01:49', '2018-10-02 01:01:49', '<form>\r\n            <div class=\"row agile-contact-mid mb-lg-4 mb-3\">\r\n               <div class=\"col-lg-4 col-md-4 form-group contact-forms\">\r\n                  <input type=\"text\" class=\"form-control\" placeholder=\"Nombre\">\r\n               </div>\r\n               <div class=\"col-lg-4 col-md-4 form-group contact-forms\">\r\n                  <input type=\"email\" class=\"form-control\" placeholder=\"Email\">\r\n               </div>\r\n               <div class=\"col-lg-4 col-md-4 form-group contact-forms\">\r\n                  <input type=\"text\" class=\"form-control\" placeholder=\"Telefono\">\r\n               </div>\r\n            </div>\r\n            <div class=\"form-group contact-forms\">\r\n               <textarea class=\"form-control\" placeholder=\"Mensaje...\" ></textarea>\r\n            </div>\r\n            <button type=\"button\" class=\"btn sent-butnn btn-lg \">Enviar</button>\r\n         </form>\n1\nAcademia de Formación \"[your-subject]\"\n[your-name] <mixsyandreapadilla@gmail.com>\nmixsyandreapadilla@gmail.com\nFrom: [your-name] <[your-email]>\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Academia de Formación (http://localhost:8080)\nReply-To: [your-email]\n\n\n\n\nAcademia de Formación \"[your-subject]\"\nAcademia de Formación <mixsyandreapadilla@gmail.com>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Academia de Formación (http://localhost:8080)\nReply-To: mixsyandreapadilla@gmail.com\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2018-10-02 18:41:49', '2018-10-02 21:41:49', '', 0, 'http://localhost:8080/?post_type=wpcf7_contact_form&#038;p=96', 0, 'wpcf7_contact_form', '', 0),
(97, 1, '2018-10-01 22:10:42', '2018-10-02 01:10:42', ' <p>Desde los  5 años de edad sin límites de edad. Desarrollo de las artes escénicas de Danza, actuación y canto, integradas en una performance escénica.</p>', 'TEATRO MUSICAL', '', 'publish', 'closed', 'closed', '', 'danza-moderna', '', '', '2018-10-02 18:32:40', '2018-10-02 21:32:40', '', 0, 'http://localhost:8080/?post_type=home&#038;p=97', 0, 'home', '', 0),
(98, 1, '2018-10-01 22:09:47', '2018-10-02 01:09:47', '', 'ini3', '', 'inherit', 'open', 'closed', '', 'ini3', '', '', '2018-10-01 22:09:47', '2018-10-02 01:09:47', '', 97, 'http://localhost:8080/wp-content/uploads/2018/10/ini3.png', 0, 'attachment', 'image/png', 0),
(99, 1, '2018-10-01 22:11:59', '2018-10-02 01:11:59', ' <p>Desde los 6 años de edad; trabajo corporal y musical, también trabajo acrobático,  a través de técnicas modernas como: jazz contemporáneo, lirical y Street jazz.</p>', 'DANZAS MODERNAS', '', 'publish', 'closed', 'closed', '', 'pareja', '', '', '2018-10-02 18:32:05', '2018-10-02 21:32:05', '', 0, 'http://localhost:8080/?post_type=home&#038;p=99', 0, 'home', '', 0),
(100, 1, '2018-10-01 22:11:29', '2018-10-02 01:11:29', '', 'ini2', '', 'inherit', 'open', 'closed', '', 'ini2', '', '', '2018-10-01 22:11:43', '2018-10-02 01:11:43', '', 99, 'http://localhost:8080/wp-content/uploads/2018/10/ini2.png', 0, 'attachment', 'image/png', 0),
(101, 1, '2018-10-01 22:13:10', '2018-10-02 01:13:10', ' <p>Desde los 3 años de edad  ayudando el despertar sensorial de los niños a través del cuerpo y el movimiento de la música, acompañada siempre  de la disciplina.</p>', 'ESCUELA DE BALLET', '', 'publish', 'closed', 'closed', '', 'bailarina-ballet', '', '', '2018-10-02 18:30:53', '2018-10-02 21:30:53', '', 0, 'http://localhost:8080/?post_type=home&#038;p=101', 0, 'home', '', 0),
(102, 1, '2018-10-01 22:12:45', '2018-10-02 01:12:45', '', 'ini1', '', 'inherit', 'open', 'closed', '', 'ini1', '', '', '2018-10-01 22:12:54', '2018-10-02 01:12:54', '', 101, 'http://localhost:8080/wp-content/uploads/2018/10/ini1.png', 0, 'attachment', 'image/png', 0),
(104, 1, '2018-10-02 18:51:21', '2018-10-02 21:51:21', '', 'ser1', '', 'inherit', 'open', 'closed', '', 'ser1', '', '', '2018-10-02 18:51:21', '2018-10-02 21:51:21', '', 0, 'http://localhost:8080/wp-content/uploads/2018/10/ser1.jpg', 0, 'attachment', 'image/jpeg', 0),
(105, 1, '2018-10-02 19:36:45', '2018-10-02 22:36:45', ' <p>Nos interesa que, a través de la Danza y las Artes Escénicas, los alumnos puedan desarrollar una mejor conciencia corporal. Lograr un desarrollo físico más allá de lo cotidiano, entregándoles, desde sus propias capacidades, una forma de expresar dancísticamente sus necesidades y anhelos.</p>', 'bailarina-3', '', 'inherit', 'closed', 'closed', '', '92-autosave-v1', '', '', '2018-10-02 19:36:45', '2018-10-02 22:36:45', '', 92, 'http://localhost:8080/2018/10/02/92-autosave-v1/', 0, 'revision', '', 0),
(106, 1, '2018-10-02 19:44:39', '2018-10-02 22:44:39', ' <p>Nuestra academia nace de la necesidad de  entregar  herramientas. Cada alumno podrá desarrollarse de mejor manera desde lo artístico hacia el mundo cotidiano. Ayudando transversalmente  a mejorar. (En los niños principalmente) su vocabulario , expresión externa,  su  motricidad   , la disciplina y un mejor  desarrollo  socio cultural y comunicativo. En su entorno los acercámos a la cultura y las artes  desde sus propios intereses.</p>', 'bailarin-2', '', 'inherit', 'closed', 'closed', '', '94-autosave-v1', '', '', '2018-10-02 19:44:39', '2018-10-02 22:44:39', '', 94, 'http://localhost:8080/2018/10/02/94-autosave-v1/', 0, 'revision', '', 0),
(107, 1, '2018-10-02 19:45:54', '2018-10-02 22:45:54', ' <p>Nuestro principal interés es poder introducir a niños, adolescentes y adultos en el estudio de las artes escénicas.  A través de cada disciplina, la relación que estas tienen con sus propias capacidades para entregar una instancia donde puedan, principalmente, descubrir sus habilidades, talentos  y desarrollarse de una manera sana con la disciplina que más les acomode.</p>\n', 'bailarina-1', '', 'inherit', 'closed', 'closed', '', '95-autosave-v1', '', '', '2018-10-02 19:45:54', '2018-10-02 22:45:54', '', 95, 'http://localhost:8080/2018/10/02/95-autosave-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `fa_termmeta`
--

CREATE TABLE `fa_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fa_terms`
--

CREATE TABLE `fa_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `fa_terms`
--

INSERT INTO `fa_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Sin categoría', 'sin-categoria', 0),
(2, 'Nosotros', 'nosotros', 0),
(3, 'menú', 'menu', 0),
(4, 'Blog', 'blog', 0);

-- --------------------------------------------------------

--
-- Table structure for table `fa_term_relationships`
--

CREATE TABLE `fa_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `fa_term_relationships`
--

INSERT INTO `fa_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(15, 2, 0),
(36, 3, 0),
(37, 3, 0),
(38, 3, 0),
(39, 3, 0),
(40, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `fa_term_taxonomy`
--

CREATE TABLE `fa_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `fa_term_taxonomy`
--

INSERT INTO `fa_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'category', '', 0, 0),
(3, 3, 'nav_menu', '', 0, 5),
(4, 4, 'category', 'este es un blog', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `fa_usermeta`
--

CREATE TABLE `fa_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `fa_usermeta`
--

INSERT INTO `fa_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'Mixsy Padilla'),
(2, 1, 'first_name', 'Mixsy'),
(3, 1, 'last_name', 'Padilla'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'false'),
(11, 1, 'locale', 'es_CL'),
(12, 1, 'fa_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'fa_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:2:{s:64:\"b0c396e90d60dd33fd42bb13ec4d6a686dca7f5fa6d8c6bf0c4218be5eb40a4f\";a:4:{s:10:\"expiration\";i:1538009560;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.92 Safari/537.36\";s:5:\"login\";i:1536799960;}s:64:\"1ffa9356c75f4fb72bae0017982f00f5f45bf3577ebcd2278ec13469aa2e766c\";a:4:{s:10:\"expiration\";i:1539120728;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36\";s:5:\"login\";i:1537911128;}}'),
(17, 1, 'fa_dashboard_quick_press_last_post_id', '13'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(19, 1, 'closedpostboxes_section', 'a:0:{}'),
(20, 1, 'metaboxhidden_section', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(21, 1, 'fa_user-settings', 'editor=html&libraryContent=browse&mfold=o&post_dfw=off'),
(22, 1, 'fa_user-settings-time', '1538368879'),
(23, 1, 'edit_page_per_page', '20'),
(24, 1, 'closedpostboxes_acf-field-group', 'a:0:{}'),
(25, 1, 'metaboxhidden_acf-field-group', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(26, 1, 'closedpostboxes_page', 'a:0:{}'),
(27, 1, 'metaboxhidden_page', 'a:4:{i:0;s:16:\"commentstatusdiv\";i:1;s:11:\"commentsdiv\";i:2;s:7:\"slugdiv\";i:3;s:9:\"authordiv\";}'),
(30, 1, 'managenav-menuscolumnshidden', 'a:0:{}'),
(31, 1, '_yoast_wpseo_profile_updated', '1538520745'),
(32, 1, 'wpseo_title', ''),
(33, 1, 'wpseo_metadesc', ''),
(34, 1, 'wpseo_noindex_author', ''),
(35, 1, 'wpseo_content_analysis_disable', ''),
(36, 1, 'wpseo_keyword_analysis_disable', ''),
(37, 1, 'googleplus', ''),
(38, 1, 'twitter', ''),
(39, 1, 'facebook', ''),
(43, 1, 'fa_yoast_notifications', 'a:2:{i:0;a:2:{s:7:\"message\";s:529:\"Yoast SEO and Advanced Custom Fields can work together a lot better by adding a helper plugin. Please install <a href=\"http://localhost:8080/wp-admin/update.php?action=install-plugin&amp;plugin=acf-content-analysis-for-yoast-seo&amp;_wpnonce=8e89d9d326\">ACF Content Analysis for Yoast SEO</a> to make your life better. <a href=\"https://wordpress.org/plugins/acf-content-analysis-for-yoast-seo/\" aria-label=\"More information about ACF Content Analysis for Yoast SEO\" target=\"_blank\" rel=\"noopener noreferrer\">More information</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:41:\"wpseo-suggested-plugin-yoast-acf-analysis\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";a:1:{i:0;s:15:\"install_plugins\";}s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:1;a:2:{s:7:\"message\";s:164:\"Don\'t miss your crawl errors: <a href=\"http://localhost:8080/wp-admin/admin.php?page=wpseo_search_console&tab=settings\">connect with Google Search Console here</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:17:\"wpseo-dismiss-gsc\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}}'),
(44, 1, 'meta-box-order_about', 'a:4:{s:15:\"acf_after_title\";s:0:\"\";s:4:\"side\";s:51:\"submitdiv,postimagediv,categorydiv,tagsdiv-post_tag\";s:6:\"normal\";s:42:\"wpseo_meta,acf-group_5bb28e16a6254,slugdiv\";s:8:\"advanced\";s:0:\"\";}'),
(45, 1, 'screen_layout_about', '2'),
(46, 1, 'fa_wpseo-suggested-plugin-yoast-acf-analysis', 'seen'),
(47, 2, 'nickname', 'ROXANA'),
(48, 2, 'first_name', 'ROXANA'),
(49, 2, 'last_name', 'MENDOZA SILVA'),
(50, 2, 'description', ''),
(51, 2, 'rich_editing', 'true'),
(52, 2, 'syntax_highlighting', 'true'),
(53, 2, 'comment_shortcuts', 'false'),
(54, 2, 'admin_color', 'fresh'),
(55, 2, 'use_ssl', '0'),
(56, 2, 'show_admin_bar_front', 'true'),
(57, 2, 'locale', ''),
(58, 2, 'fa_capabilities', 'a:1:{s:6:\"editor\";b:1;}'),
(59, 2, 'fa_user_level', '7'),
(60, 2, '_yoast_wpseo_profile_updated', '1538520663'),
(61, 2, 'dismissed_wp_pointers', 'wp496_privacy'),
(62, 1, 'users_per_page', '20');

-- --------------------------------------------------------

--
-- Table structure for table `fa_users`
--

CREATE TABLE `fa_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `fa_users`
--

INSERT INTO `fa_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'mixsypadilla', '$P$BD7kxy8H7o4/zYi4VVEXlLOZwhnGOC/', 'mixsypadilla', 'mixsyandreapadilla@gmail.com', '', '2018-09-13 00:52:20', '', 0, 'Mixsy'),
(2, 'ROXANA', '$P$BtpM5kymWkNWnfJfFHT724JqYM6tJd/', 'roxana', 'servicioswebereirl@gmail.com', '', '2018-10-02 22:51:02', '1538520664:$P$BiDPQnPW2ns/7hy87XF.vjkHgx.pGw/', 0, 'ROXANA MENDOZA SILVA');

-- --------------------------------------------------------

--
-- Table structure for table `fa_yoast_seo_links`
--

CREATE TABLE `fa_yoast_seo_links` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `target_post_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `fa_yoast_seo_links`
--

INSERT INTO `fa_yoast_seo_links` (`id`, `url`, `post_id`, `target_post_id`, `type`) VALUES
(1, 'index.html', 5, 0, 'internal');

-- --------------------------------------------------------

--
-- Table structure for table `fa_yoast_seo_meta`
--

CREATE TABLE `fa_yoast_seo_meta` (
  `object_id` bigint(20) UNSIGNED NOT NULL,
  `internal_link_count` int(10) UNSIGNED DEFAULT NULL,
  `incoming_link_count` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `fa_yoast_seo_meta`
--

INSERT INTO `fa_yoast_seo_meta` (`object_id`, `internal_link_count`, `incoming_link_count`) VALUES
(5, 1, 0),
(23, 0, 0),
(69, 0, 0),
(81, 0, 0),
(85, 0, 0),
(86, 0, 0),
(87, 0, 0),
(89, 0, 0),
(91, 0, 0),
(92, 0, 0),
(94, 0, 0),
(95, 0, 0),
(97, 0, 0),
(99, 0, 0),
(101, 0, 0),
(103, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fa_commentmeta`
--
ALTER TABLE `fa_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `fa_comments`
--
ALTER TABLE `fa_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `fa_duplicator_packages`
--
ALTER TABLE `fa_duplicator_packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hash` (`hash`);

--
-- Indexes for table `fa_il_local`
--
ALTER TABLE `fa_il_local`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fa_links`
--
ALTER TABLE `fa_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `fa_options`
--
ALTER TABLE `fa_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `fa_postmeta`
--
ALTER TABLE `fa_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `fa_posts`
--
ALTER TABLE `fa_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `fa_termmeta`
--
ALTER TABLE `fa_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `fa_terms`
--
ALTER TABLE `fa_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `fa_term_relationships`
--
ALTER TABLE `fa_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `fa_term_taxonomy`
--
ALTER TABLE `fa_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `fa_usermeta`
--
ALTER TABLE `fa_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `fa_users`
--
ALTER TABLE `fa_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Indexes for table `fa_yoast_seo_links`
--
ALTER TABLE `fa_yoast_seo_links`
  ADD PRIMARY KEY (`id`),
  ADD KEY `link_direction` (`post_id`,`type`);

--
-- Indexes for table `fa_yoast_seo_meta`
--
ALTER TABLE `fa_yoast_seo_meta`
  ADD UNIQUE KEY `object_id` (`object_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fa_commentmeta`
--
ALTER TABLE `fa_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fa_comments`
--
ALTER TABLE `fa_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `fa_duplicator_packages`
--
ALTER TABLE `fa_duplicator_packages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fa_il_local`
--
ALTER TABLE `fa_il_local`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fa_links`
--
ALTER TABLE `fa_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fa_options`
--
ALTER TABLE `fa_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=530;
--
-- AUTO_INCREMENT for table `fa_postmeta`
--
ALTER TABLE `fa_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=282;
--
-- AUTO_INCREMENT for table `fa_posts`
--
ALTER TABLE `fa_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;
--
-- AUTO_INCREMENT for table `fa_termmeta`
--
ALTER TABLE `fa_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fa_terms`
--
ALTER TABLE `fa_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `fa_term_taxonomy`
--
ALTER TABLE `fa_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `fa_usermeta`
--
ALTER TABLE `fa_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT for table `fa_users`
--
ALTER TABLE `fa_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `fa_yoast_seo_links`
--
ALTER TABLE `fa_yoast_seo_links`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
